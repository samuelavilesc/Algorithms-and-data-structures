#include <iostream>
#include <string>
#include "interprete.h"
using namespace std;




int main (){
    elegir();
    
    return 0;
}