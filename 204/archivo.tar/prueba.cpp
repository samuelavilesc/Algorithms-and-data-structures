#include<iostream>
#include<algorithm>
#include<string>

std::string ordenarAlfabeticamente(std::string str) {
    std::sort(str.begin(), str.end());
    return str;
}

int main() {
    std::string str = "hola mundo";
    std::cout << ordenarAlfabeticamente(str) << std::endl;
    return 0;
}
