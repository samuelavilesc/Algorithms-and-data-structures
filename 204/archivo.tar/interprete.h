#ifndef INTERPRETE_H
#define INTERPRETE_H
#include<string>
#include<iostream>
#include "normalizarPalabra.h"
#include "diccionarioPalabras.h"
using namespace std;
void insertar();
void buscar();
void partidas();
void alocado();
void cesar();
void juanagra();
void saco();
void consome();
void alarga();
void vaciar();
void elegir();


#endif