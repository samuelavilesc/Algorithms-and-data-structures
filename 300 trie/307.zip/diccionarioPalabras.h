#ifndef DICCIONARIOPALABRAS_H
#define DICCIONARIOPALABRAS_H
#include<list>
#include<string>
#include "normalizarPalabra.h"
#include "TablaHash.h"
#include "AVL.h"
#include"ArbolAlarga.h"
using namespace std;
class diccionarioPalabras{
private:
    TablaHash tabla;
    Arbol arbol;
    ArbolAlarga arbolAlarga;
    string ordenarPalabra(string palabra);
public:
diccionarioPalabras();
void insertarPalabra(string palabra);
bool consultarPalabra(string palabra);
void vaciarDiccionario();
int devolverTamano();
string alarga(string palabra);
};
#endif