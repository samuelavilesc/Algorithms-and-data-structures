#include "diccionarioPalabras.h"
using namespace std;
diccionarioPalabras::diccionarioPalabras(){
    this->tabla=TablaHash();
    this->arbol=Arbol();
    this->arbolAlarga=ArbolAlarga();
}

void diccionarioPalabras::insertarPalabra(string palabra){
arbolAlarga.inserta(normalizarPalabra(palabra));
}
bool diccionarioPalabras::consultarPalabra(string palabra){
    return arbolAlarga.consultar(normalizarPalabra(palabra));
}
void diccionarioPalabras::vaciarDiccionario(){
    arbolAlarga.vaciar();
}
int diccionarioPalabras::devolverTamano(){
    return arbolAlarga.nElementos();
}
string diccionarioPalabras::alarga(string palabra){
    return arbolAlarga.alarga(normalizarPalabra(palabra));
}

