#include "ArbolAlarga.h"

NodoPartidas::NodoPartidas()
{
    izq = NULL;
    der = NULL;
    h = 1;
}

NodoPartidas::~NodoPartidas()
{
    delete izq;
    delete der;
}

int NodoPartidas::altura()
{
    if (this == NULL)
    {
        return 0;
    }

    return this->h;
}

int NodoPartidas::alturaMaxima(int a, int b)
{
    if ( a > b )
        return a;
    return b;
}

int NodoPartidas::fBalance()
{
    if (this == NULL)
        return 0;
    return this->izq->altura() - this->der->altura();
}

NodoPartidas* NodoPartidas::RSD()
{
    NodoPartidas *B = this->der;
    NodoPartidas *C = B->izq;
    B->izq = this;
    this->der = C;

    this->h =this->alturaMaxima(  this->izq->altura(),  this->der->altura() ) + 1;
    B->h =B->alturaMaxima(  B->izq->altura(),  B->der->altura() ) + 1;

    return B;
}

NodoPartidas* NodoPartidas::RSI() 
{
    NodoPartidas *B = this->izq;
    NodoPartidas *C = B->der;
    B->der = this;
    this->izq = C;

    this->h =this->alturaMaxima(  this->izq->altura(),  this->der->altura() ) + 1;
    B->h =B->alturaMaxima(  B->izq->altura(),  B->der->altura() ) + 1;
    return B;
}
bool NodoPartidas::consultar(string& palabra)
{
    if (this->palabra == palabra)
    {
        return true;
    }

    if (this->palabra.compare(palabra) > 0)
    {
        if (this->izq == NULL)
        {
            return false;
        }
        else
        {
            return this->izq->consultar(palabra);
        }
    }
    else
    {
        if (this->der == NULL)
        {
            return false;
        }
        else
        {
            return this->der->consultar(palabra);
        }
    }
}

NodoPartidas* insertar(string& palabra, NodoPartidas *nodo)
{
    if( nodo == NULL )
    {
        nodo = new NodoPartidas;
        nodo->palabra = palabra;
        return nodo;
        
    }
    if(palabra.compare(nodo->palabra) < 0 )
    {
        nodo->izq = insertar(palabra, nodo->izq);
    } else if ( palabra.compare(nodo->palabra) > 0 )
    {
        nodo->der = insertar(palabra, nodo->der);
    } else 
    {
        nodo->palabra = palabra;
        return nodo;
    }
    //rebalancear
    nodo->h=1+nodo->alturaMaxima(nodo->izq->altura(), nodo->der->altura());
    int fBal = nodo->fBalance();

    if ( fBal > 1 )
    {
        if ( palabra.compare( nodo->izq->palabra ) < 0)
        {
            return nodo->RSI();
        }
        else 
        {
            nodo->izq = nodo->izq->RSD();
            return nodo->RSI();
        }

    }
    else if ( fBal < -1 )
    {
        if ( palabra.compare( nodo->der->palabra) > 0)
        {
            return nodo->RSD();
        }
        else 
        {
            nodo->der = nodo->der->RSI();
            return nodo->RSD();
        }
    }
    return nodo;
}

ArbolAlarga::ArbolAlarga(){
    raiz = NULL;
    nElem = 0;
}

ArbolAlarga::~ArbolAlarga()
{
    delete raiz;
}

void ArbolAlarga::inserta(string palabra)
{
    if(consultar(palabra))
    {
        return;
    }
    nElem++;
    raiz = insertar(palabra, raiz);
}

bool ArbolAlarga::consultar(string palabra)
{
    if (raiz == NULL)
    {
        return false;
    }
    else
    {
        return raiz->consultar(palabra);
    }
}
int ArbolAlarga::nElementos()
{
    return nElem;
}
void ArbolAlarga::vaciar(){
    this->~ArbolAlarga();
    raiz=NULL;
    nElem=0;
}
int longitudPalabra(string palabra){
    int longitud=0;
    int i=0;
    while(i<palabra.length()){
        if(palabra[i]=='\xC3'){
            switch (palabra[i+1])
            {
            case '\xB1':
                longitud++;
                break;
            case '\xBC':
                longitud++;
                break;
            default:
                longitud++;
                break;
            }
            i+=2;
        }else{
            i++;
            longitud++;
        }
    }
    return longitud;
}
/*
string salida="";
int contador=0;
void inOrden(NodoPartidas *raiz, string palabra){

    NodoPartidas *arbol=raiz;
    if (arbol==NULL){
        return;
    }
    else{
        inOrden(arbol->izq,palabra);
        string fragmento="";
        fragmento.append(arbol->palabra,0,palabra.length());
        if(fragmento==palabra){
            if(longitudPalabra(arbol->palabra)>contador){
                contador=longitudPalabra(arbol->palabra);
                salida=arbol->palabra;
            }                                                       
        }
        inOrden(arbol->der,palabra);
    }
}*/
string buscar(NodoPartidas *raiz,string& palabra)
{

    string salida="";
    int contador = 0;
    NodoPartidas *arbol=raiz;
    if(arbol==NULL){
        return "";
    }
    string fragmento="";
        fragmento.append(arbol->palabra,0,palabra.length());
        if(fragmento==palabra){
            if(longitudPalabra(arbol->palabra)>contador){
                contador=longitudPalabra(arbol->palabra);
                salida=arbol->palabra;
            }
        }
    if (arbol->palabra.compare(palabra) > 0)
    {
        if (arbol->izq == NULL)
        {
            return salida;
        }
        else
        {
            return buscar(arbol->izq,palabra);
        }
    
    }else{
        if (arbol->der == NULL)
        {
            return salida;
        }
        else
        {
            return buscar(arbol->der,palabra);
        }
    }
}

string ArbolAlarga::alarga(string palabra){
   /* salida="";
    contador=0;
    inOrden(raiz,palabra);*/
    return buscar(raiz,palabra);
}