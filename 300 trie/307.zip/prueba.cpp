#include<iostream>
#include<string>

using namespace std;
int longitudPalabra(string palabra){
    int longitud=0;
    int i=0;
    while(i<palabra.length()){
        if(palabra[i]=='\xC3'){
            switch (palabra[i+1])
            {
            case '\xB1':
                longitud++;
                break;
            case '\xBC':
                longitud++;
                break;
            default:
                longitud++;
                break;
            }
            i+=2;
        }else{
            i++;
            longitud++;
        }
    }
    return longitud;
}
int main (){
    string hola="CIGÜEÑA";
    cout<<longitudPalabra(hola)<<endl;

    return 0;
}