#ifndef ARBOLALARGA_H
#define ARBOLALARGA_H
#include <string>
#include <list>
#include <algorithm>
using namespace std;

class NodoPartidas {
   friend class ArbolAlarga;
   public:
      NodoPartidas* izq;
      NodoPartidas* der; 
      string palabra;
      int h;

      NodoPartidas ();
      ~NodoPartidas ();
      int fBalance ();
      int alturaMaxima (int a, int b);
      int altura ();
      NodoPartidas* RSI();
      NodoPartidas* RSD();
      NodoPartidas* insertar(string& palabra);
      bool consultar(string& palabra);
};

class ArbolAlarga {
   private:
      NodoPartidas *raiz;
      int nElem;
   public:
      ArbolAlarga ();
      ~ArbolAlarga ();
      void inserta (string palabra);
      bool consultar (string palabra);
      int nElementos ();
      void vaciar();
      string alarga(string palabra);
};

#endif