#ifndef NORMALIZARPALABRA_H
#define NORMALIZARPALABRA_H
#include<string>
using namespace std;
string normalizarPalabra(string str);
#endif